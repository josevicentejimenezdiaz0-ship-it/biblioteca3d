# Biblioteca 3D

Biblioteca de mundo abierto en 3D para Android (armeabi-v7a) donde caminas entre estanterías
y cada libro es uno de tus archivos reales PDF, EPUB o TXT.

## Qué hace

- **Archivos reales**: se añaden con el selector del sistema (`+ Archivos`) o escaneando una
  carpeta entera (`Carpeta`, incluye subcarpetas). Se guarda la referencia al archivo, no una copia,
  y no se piden permisos de almacenamiento.
- **Mundo 3D**: joystick para caminar, arrastrar para mirar, toque corto para seleccionar un libro.
  Colores: PDF rojo, EPUB verde, TXT azul. El grosor del libro depende del tamaño del archivo.
- **Leer**: `Abrir y leer` lanza el archivo con la app externa que elijas. El libro queda
  "en tus manos" (sobresale de la estantería).
- **Soltar**: al volver de la app lectora (o con `Soltar`) anotas página/capítulo y porcentaje.
  La próxima vez la ficha del libro y el botón `Continuar` te recuerdan por dónde ibas.
- **Ordenar a tu gusto**: manual (◀ ▶ en cada libro), título, añadidos, leídos recientemente,
  tu puntuación (★ 0-5), favoritos (♥), progreso, en lectura, tipo y tamaño. Con `Invertir orden`.
  La distribución de las estanterías cambia al instante según el orden elegido.
- `Buscar` te teletransporta junto a cualquier libro.

## Compilar el APK

Requisitos: JDK 17 o superior y Android SDK con la plataforma `android-34`
(lo más fácil: abrir la carpeta con Android Studio).

```bash
# Linux / macOS
export ANDROID_HOME=$HOME/Android/Sdk      # ruta de tu SDK
./gradlew assembleDebug
```

El APK queda en `app/build/outputs/apk/debug/app-debug.apk`. Cópialo al móvil e instálalo
(hay que permitir "instalar apps de orígenes desconocidos").

## Notas técnicas

- `minSdk 21`, `targetSdk 34`, filtro de ABI `armeabi-v7a`.
- Sin librerías externas ni código nativo: OpenGL ES 2.0 desde Kotlin.
- Datos en `SharedPreferences` (JSON). El progreso es manual porque la lectura ocurre en una app externa
  que no informa de la página.
- Si mueves o borras un archivo, la app avisa al abrirlo; quítalo y vuelve a añadirlo.
