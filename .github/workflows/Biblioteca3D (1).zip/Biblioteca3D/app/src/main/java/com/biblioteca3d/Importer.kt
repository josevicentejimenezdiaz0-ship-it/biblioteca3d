package com.biblioteca3d

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns

class Found(val uri: Uri, val name: String, val size: Long, val type: String)

object Importer {

    /** "pdf", "epub", "txt" o null si el archivo no es de un tipo soportado. */
    fun typeOf(name: String, mime: String?): String? {
        val n = name.lowercase()
        return when {
            n.endsWith(".pdf") || mime == "application/pdf" -> "pdf"
            n.endsWith(".epub") || mime == "application/epub+zip" -> "epub"
            n.endsWith(".txt") || mime == "text/plain" -> "txt"
            else -> null
        }
    }

    fun mimeOf(type: String): String = when (type) {
        "pdf" -> "application/pdf"
        "epub" -> "application/epub+zip"
        else -> "text/plain"
    }

    /** Lee nombre y tamano de un archivo elegido con el selector del sistema. */
    fun queryFile(cr: ContentResolver, uri: Uri): Found? {
        var name: String? = null
        var size = 0L
        try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        name = c.getString(0)
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
        } catch (e: Exception) {
        }
        val n = name ?: uri.lastPathSegment ?: return null
        val type = typeOf(n, cr.getType(uri)) ?: return null
        return Found(uri, n, size, type)
    }

    /** Recorre una carpeta (y subcarpetas) buscando PDF, EPUB y TXT. */
    fun scanTree(cr: ContentResolver, tree: Uri): List<Found> {
        val out = ArrayList<Found>()
        scan(cr, tree, DocumentsContract.getTreeDocumentId(tree), 0, out)
        return out
    }

    private fun scan(cr: ContentResolver, tree: Uri, docId: String, depth: Int, out: MutableList<Found>) {
        if (depth > 8 || out.size >= 3000) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        val subdirs = ArrayList<String>()
        try {
            cr.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2)
                    val size = if (c.isNull(3)) 0L else c.getLong(3)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        subdirs.add(id)
                    } else {
                        val t = typeOf(name, mime)
                        if (t != null) {
                            out.add(Found(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, size, t))
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
        for (d in subdirs) scan(cr, tree, d, depth + 1, out)
    }
}
