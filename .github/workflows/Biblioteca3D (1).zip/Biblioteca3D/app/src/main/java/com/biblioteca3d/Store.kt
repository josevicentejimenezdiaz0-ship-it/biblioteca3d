package com.biblioteca3d

import android.content.Context
import org.json.JSONArray

/** Guarda la biblioteca en SharedPreferences (JSON) y gestiona la ordenacion. */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("biblioteca3d", Context.MODE_PRIVATE)
    val books = mutableListOf<Book>()
    var sortMode: SortMode = SortMode.MANUAL
    var reversed: Boolean = false

    init {
        load()
    }

    private fun load() {
        books.clear()
        try {
            val arr = JSONArray(prefs.getString("books", "[]"))
            for (i in 0 until arr.length()) books.add(Book.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            // datos corruptos: empezamos vacios sin romper la app
        }
        sortMode = try {
            SortMode.valueOf(prefs.getString("sort", SortMode.MANUAL.name)!!)
        } catch (e: Exception) {
            SortMode.MANUAL
        }
        reversed = prefs.getBoolean("reversed", false)
    }

    fun save() {
        val arr = JSONArray()
        for (b in books) arr.put(b.toJson())
        prefs.edit()
            .putString("books", arr.toString())
            .putString("sort", sortMode.name)
            .putBoolean("reversed", reversed)
            .apply()
    }

    fun find(id: String?): Book? = if (id == null) null else books.firstOrNull { it.id == id }

    /** Devuelve false si ya estaba en la biblioteca. */
    fun add(uri: String, name: String, size: Long, type: String): Boolean {
        if (books.any { it.id == uri }) return false
        val title = name.substringBeforeLast('.').replace('_', ' ').trim().ifEmpty { name }
        val next = (books.maxOfOrNull { it.manualOrder } ?: -1) + 1
        books.add(Book(id = uri, uri = uri, title = title, type = type, size = size,
            addedAt = System.currentTimeMillis(), manualOrder = next))
        return true
    }

    fun remove(id: String) {
        books.removeAll { it.id == id }
    }

    /** Lista en el orden elegido (con "invertir" aplicado). */
    fun sorted(): List<Book> {
        val byTitle = compareBy<Book> { it.title.lowercase() }
        val cmp: Comparator<Book> = when (sortMode) {
            SortMode.MANUAL -> compareBy<Book> { it.manualOrder }.then(byTitle)
            SortMode.TITLE -> byTitle
            SortMode.ADDED -> compareByDescending<Book> { it.addedAt }.then(byTitle)
            SortMode.LAST_READ -> compareByDescending<Book> { it.lastOpened }.then(byTitle)
            SortMode.RATING -> compareByDescending<Book> { it.rating }.then(byTitle)
            SortMode.FAVORITES -> compareByDescending<Book> { it.favorite }
                .thenByDescending { it.rating }.then(byTitle)
            SortMode.PROGRESS -> compareByDescending<Book> { it.progress }.then(byTitle)
            SortMode.READING -> compareByDescending<Book> { it.reading }
                .thenByDescending { it.lastOpened }.then(byTitle)
            SortMode.TYPE -> compareBy<Book> { it.type }.then(byTitle)
            SortMode.SIZE -> compareByDescending<Book> { it.size }.then(byTitle)
        }
        val list = books.sortedWith(cmp)
        return if (reversed) list.reversed() else list
    }

    /** Mueve un libro una posicion antes (-1) o despues (+1) y pasa a orden manual. */
    fun move(id: String, delta: Int) {
        val list = sorted().toMutableList()
        val i = list.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) return
        val tmp = list[i]; list[i] = list[j]; list[j] = tmp
        list.forEachIndexed { index, b -> b.manualOrder = index }
        sortMode = SortMode.MANUAL
        reversed = false
    }
}
