package com.biblioteca3d

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var renderer: WorldRenderer
    private lateinit var glView: GLSurfaceView
    private lateinit var panel: LinearLayout
    private lateinit var tvTitle: TextView
    private lateinit var tvInfo: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var tvSort: TextView
    private lateinit var btnDrop: Button
    private lateinit var btnRate: Button
    private lateinit var btnFav: Button

    private var selectedId: String? = null
    private var awaitingReturnId: String? = null

    // Estado del gesto de mirar / tocar
    private var lookId = -1
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L
    private var moved = false

    private val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        renderer = WorldRenderer()
        renderer.onPick = { id -> runOnUiThread { select(id) } }

        glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(2)
        glView.setRenderer(renderer)
        glView.setOnTouchListener { _, e -> handleLook(e); true }

        val root = FrameLayout(this)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        root.addView(glView, FrameLayout.LayoutParams(match, match))

        val joy = JoystickView(this)
        joy.onChange = { x, y -> renderer.moveX = x; renderer.moveY = y }
        root.addView(joy, FrameLayout.LayoutParams(dp(170), dp(170), Gravity.BOTTOM or Gravity.START)
            .apply { setMargins(dp(24), 0, 0, dp(24)) })

        // Barra superior
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0x88000000.toInt())
            setPadding(dp(4), dp(2), dp(4), dp(2))
            addView(btn("+ Archivos") { pickFiles() })
            addView(btn("Carpeta") { pickFolder() })
            addView(btn("Ordenar") { showSortDialog() })
            addView(btn("Buscar") { showSearchDialog() })
            addView(btn("Continuar") { continueReading() })
        }
        root.addView(bar, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END))

        tvSort = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
        }
        root.addView(tvSort, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.START)
            .apply { setMargins(dp(12), dp(10), 0, 0) })

        tvEmpty = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            text = "Tu biblioteca está vacía.\nPulsa «+ Archivos» o «Carpeta» para añadir tus PDF, EPUB y TXT.\n\n" +
                "Joystick = caminar · Arrastrar = mirar · Tocar un libro = seleccionarlo"
        }
        root.addView(tvEmpty, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))

        root.addView(buildPanel(), FrameLayout.LayoutParams(dp(320), wrap, Gravity.BOTTOM or Gravity.END)
            .apply { setMargins(0, 0, dp(12), dp(12)) })

        setContentView(root)
        refresh()
    }

    private fun btn(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        setAllCaps(false)
        textSize = 13f
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { onClick() }
    }

    private fun buildPanel(): LinearLayout {
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEEFFFFFF.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            visibility = View.GONE
        }
        tvTitle = TextView(this).apply { textSize = 17f; setTextColor(Color.BLACK) }
        tvInfo = TextView(this).apply { textSize = 12f; setTextColor(0xFF444444.toInt()) }
        tvStatus = TextView(this).apply { textSize = 13f; setTextColor(0xFF1B4F8A.toInt()) }
        panel.addView(tvTitle)
        panel.addView(tvInfo)
        panel.addView(tvStatus)

        btnDrop = btn("Soltar") { currentBook()?.let { if (it.reading) dropBook(it) } }
        btnRate = btn("★ 0") {
            currentBook()?.let { it.rating = (it.rating + 1) % 6; commit() }
        }
        btnFav = btn("♡") {
            currentBook()?.let { it.favorite = !it.favorite; commit() }
        }
        panel.addView(row(btn("Abrir y leer") { currentBook()?.let { openBook(it) } }, btnDrop))
        panel.addView(row(btnRate, btnFav,
            btn("◀") { moveSelected(-1) }, btn("▶") { moveSelected(1) }))
        panel.addView(row(btn("Quitar") { currentBook()?.let { confirmRemove(it) } },
            btn("Cerrar") { select(null) }))
        return panel
    }

    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (v in views) addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    // ---------- Estado y refresco ----------

    private fun currentBook(): Book? = store.find(selectedId)

    private fun commit() {
        store.save()
        refresh()
    }

    private fun refresh() {
        val list = store.sorted()
        renderer.setBooks(list)
        tvSort.text = "Orden: ${store.sortMode.label}${if (store.reversed) " (invertido)" else ""} · ${list.size} libros"
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        if (store.find(selectedId) == null) {
            selectedId = null
            renderer.selectedId = null
        }
        updatePanel()
    }

    private fun select(id: String?) {
        selectedId = id
        renderer.selectedId = id
        updatePanel()
    }

    private fun fmtSize(size: Long): String =
        if (size >= 1048576L) String.format(Locale.getDefault(), "%.1f MB", size / 1048576.0)
        else String.format(Locale.getDefault(), "%d KB", size / 1024)

    private fun updatePanel() {
        val b = currentBook()
        if (b == null) {
            panel.visibility = View.GONE
            return
        }
        panel.visibility = View.VISIBLE
        tvTitle.text = b.title
        tvInfo.text = "${b.type.uppercase()} · ${fmtSize(b.size)} · añadido ${df.format(Date(b.addedAt))}"
        val where = "pág./cap. ${b.page} · ${b.progress}%"
        tvStatus.text = when {
            b.reading -> "En tus manos desde ${df.format(Date(b.lastOpened))}\nVas por: $where"
            b.progress > 0 || b.page > 0 -> "Soltado en: $where\nÚltima lectura: ${df.format(Date(b.lastOpened))}"
            else -> "Sin empezar"
        }
        btnDrop.isEnabled = b.reading
        btnRate.text = "★ ${b.rating}"
        btnFav.text = if (b.favorite) "♥" else "♡"
    }

    // ---------- Lectura: abrir y soltar ----------

    private fun openBook(b: Book) {
        val uri = Uri.parse(b.uri)
        val target = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, Importer.mimeOf(b.type))
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(target, "Abrir «${b.title}» con…").apply {
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            if (b.progress > 0 || b.page > 0) {
                toast("Sigue por: pág./cap. ${b.page} (${b.progress}%)")
            }
            startActivity(chooser)
            b.reading = true
            b.lastOpened = System.currentTimeMillis()
            awaitingReturnId = b.id
            commit()
        } catch (e: ActivityNotFoundException) {
            toast("No hay ninguna app instalada que abra archivos ${b.type.uppercase()}.")
        } catch (e: SecurityException) {
            toast("No se pudo acceder al archivo. ¿Lo moviste o lo borraste? Quítalo y vuelve a añadirlo.")
        }
    }

    /** "Soltar" el libro: anotas por donde vas y vuelve a la estanteria. */
    private fun dropBook(b: Book) {
        val lay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), 0)
        }
        val etPage = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Página o capítulo por donde vas"
            if (b.page > 0) setText(b.page.toString())
        }
        val etPct = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Progreso total (0-100 %)"
            setText(b.progress.toString())
        }
        lay.addView(etPage)
        lay.addView(etPct)
        AlertDialog.Builder(this)
            .setTitle("Soltar «${b.title}»")
            .setMessage("Anota por dónde lo dejas para continuar después.")
            .setView(lay)
            .setPositiveButton("Soltar en la estantería") { _, _ ->
                b.page = etPage.text.toString().toIntOrNull() ?: 0
                b.progress = (etPct.text.toString().toIntOrNull() ?: b.progress).coerceIn(0, 100)
                b.reading = false
                commit()
                toast("Libro soltado. La próxima vez seguirás por pág./cap. ${b.page} (${b.progress}%).")
            }
            .setNegativeButton("Seguir leyendo", null)
            .show()
    }

    /** Boton "Continuar": reabre el ultimo libro que estabas leyendo. */
    private fun continueReading() {
        val b = store.books.filter { it.reading }.maxByOrNull { it.lastOpened }
            ?: store.books.filter { it.lastOpened > 0L }.maxByOrNull { it.lastOpened }
        if (b == null) {
            toast("Todavía no has leído ningún libro.")
            return
        }
        renderer.teleportId = b.id
        select(b.id)
        openBook(b)
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
        // Al volver de la app lectora, ofrecemos anotar por donde lo dejaste
        val id = awaitingReturnId
        if (id != null) {
            awaitingReturnId = null
            val b = store.find(id)
            if (b != null && b.reading) dropBook(b)
        }
    }

    override fun onPause() {
        super.onPause()
        glView.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    // ---------- Orden, busqueda, borrado ----------

    private fun showSortDialog() {
        val modes = SortMode.values()
        AlertDialog.Builder(this)
            .setTitle("Ordenar la biblioteca")
            .setSingleChoiceItems(modes.map { it.label }.toTypedArray(), store.sortMode.ordinal) { d, which ->
                store.sortMode = modes[which]
                commit()
                d.dismiss()
                if (modes[which] == SortMode.MANUAL) {
                    toast("Selecciona un libro y usa ◀ ▶ para colocarlo donde quieras.")
                }
            }
            .setNeutralButton(if (store.reversed) "Quitar inversión" else "Invertir orden") { _, _ ->
                store.reversed = !store.reversed
                commit()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun moveSelected(delta: Int) {
        val id = selectedId ?: return
        store.move(id, delta)
        commit()
        val pos = store.sorted().indexOfFirst { it.id == id } + 1
        toast("Posición $pos de ${store.books.size} (orden manual)")
    }

    private fun showSearchDialog() {
        val list = store.sorted()
        if (list.isEmpty()) {
            toast("La biblioteca está vacía.")
            return
        }
        val names = list.map { "${it.title} · ${it.type.uppercase()}${if (it.reading) " · en lectura" else ""}" }
        AlertDialog.Builder(this)
            .setTitle("Ir a un libro")
            .setItems(names.toTypedArray()) { _, which ->
                renderer.teleportId = list[which].id
                select(list[which].id)
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun confirmRemove(b: Book) {
        AlertDialog.Builder(this)
            .setTitle("Quitar «${b.title}»")
            .setMessage("Se quita de la biblioteca. El archivo original NO se borra de tu almacenamiento.")
            .setPositiveButton("Quitar") { _, _ ->
                try {
                    contentResolver.releasePersistableUriPermission(
                        Uri.parse(b.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                store.remove(b.id)
                selectedId = null
                commit()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Importar archivos reales ----------

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_FILES)
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_TREE)
    }

    @Deprecated("Se mantiene startActivityForResult para no depender de AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_FILES -> {
                val uris = ArrayList<Uri>()
                val cd = data.clipData
                if (cd != null) {
                    for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
                } else {
                    data.data?.let { uris.add(it) }
                }
                var added = 0
                var dup = 0
                var skipped = 0
                for (u in uris) {
                    try {
                        contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (e: Exception) {
                    }
                    val f = Importer.queryFile(contentResolver, u)
                    if (f == null) skipped++
                    else if (store.add(f.uri.toString(), f.name, f.size, f.type)) added++
                    else dup++
                }
                commit()
                toast("Añadidos: $added · ya existían: $dup · no compatibles (solo PDF, EPUB, TXT): $skipped")
            }
            REQ_TREE -> {
                val tree = data.data ?: return
                try {
                    contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                toast("Buscando libros en la carpeta…")
                Thread {
                    val found = Importer.scanTree(contentResolver, tree)
                    runOnUiThread {
                        var added = 0
                        for (f in found) if (store.add(f.uri.toString(), f.name, f.size, f.type)) added++
                        commit()
                        toast("Encontrados ${found.size} archivos · nuevos en la biblioteca: $added")
                    }
                }.start()
            }
        }
    }

    // ---------- Gesto: arrastrar = mirar, toque corto = seleccionar ----------

    private fun handleLook(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> if (lookId == -1) {
                val i = e.actionIndex
                lookId = e.getPointerId(i)
                lastX = e.getX(i); lastY = e.getY(i)
                downX = lastX; downY = lastY
                downT = e.eventTime
                moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                val i = e.findPointerIndex(lookId)
                if (i >= 0) {
                    val x = e.getX(i)
                    val y = e.getY(i)
                    renderer.yaw += (x - lastX) * 0.25f
                    renderer.pitch = (renderer.pitch - (y - lastY) * 0.25f).coerceIn(-80f, 80f)
                    lastX = x; lastY = y
                    if (hypot(x - downX, y - downY) > dp(10)) moved = true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val i = e.actionIndex
                if (e.getPointerId(i) == lookId) {
                    if (!moved && e.actionMasked != MotionEvent.ACTION_CANCEL && e.eventTime - downT < 350) {
                        val x = e.getX(i)
                        val y = e.getY(i)
                        glView.queueEvent { renderer.pick(x, y) }
                    }
                    lookId = -1
                }
            }
        }
    }

    companion object {
        private const val REQ_FILES = 1
        private const val REQ_TREE = 2
    }
}
