package com.biblioteca3d

import org.json.JSONObject

/** Un archivo real del almacenamiento del usuario (se guarda su URI, no una copia). */
data class Book(
    val id: String,              // la propia URI en texto: es unica
    val uri: String,
    val title: String,
    val type: String,            // "pdf", "epub" o "txt"
    val size: Long,
    val addedAt: Long,
    var lastOpened: Long = 0L,
    var progress: Int = 0,       // 0..100 %
    var page: Int = 0,           // marcador libre: pagina o capitulo
    var favorite: Boolean = false,
    var rating: Int = 0,         // 0..5 (tus gustos)
    var manualOrder: Int = 0,
    var reading: Boolean = false // true = el libro esta "en tus manos" (sobresale de la estanteria)
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("uri", uri)
        put("title", title)
        put("type", type)
        put("size", size)
        put("addedAt", addedAt)
        put("lastOpened", lastOpened)
        put("progress", progress)
        put("page", page)
        put("favorite", favorite)
        put("rating", rating)
        put("manualOrder", manualOrder)
        put("reading", reading)
    }

    companion object {
        fun fromJson(o: JSONObject): Book = Book(
            id = o.getString("id"),
            uri = o.getString("uri"),
            title = o.getString("title"),
            type = o.getString("type"),
            size = o.optLong("size", 0L),
            addedAt = o.optLong("addedAt", 0L),
            lastOpened = o.optLong("lastOpened", 0L),
            progress = o.optInt("progress", 0),
            page = o.optInt("page", 0),
            favorite = o.optBoolean("favorite", false),
            rating = o.optInt("rating", 0),
            manualOrder = o.optInt("manualOrder", 0),
            reading = o.optBoolean("reading", false)
        )
    }
}

/** Formas de ordenar la biblioteca. Cada comparador pone primero lo "mas util". */
enum class SortMode(val label: String) {
    MANUAL("Orden manual (el que tú decidas)"),
    TITLE("Título (A-Z)"),
    ADDED("Añadidos recientemente"),
    LAST_READ("Leídos recientemente"),
    RATING("Mi puntuación (más gustados primero)"),
    FAVORITES("Favoritos primero"),
    PROGRESS("Más avanzados primero"),
    READING("En lectura primero"),
    TYPE("Tipo (PDF, EPUB, TXT)"),
    SIZE("Tamaño (mayores primero)")
}
