package com.biblioteca3d

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLU
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class WorldRenderer : GLSurfaceView.Renderer {

    // Estado compartido con la interfaz (se escribe en el hilo de UI, se lee en el de GL)
    @Volatile var layout: Layout = WorldBuilder.build(emptyList())
    @Volatile var yaw = 0f
    @Volatile var pitch = -5f
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f
    @Volatile var selectedId: String? = null
    @Volatile var teleportId: String? = null
    var onPick: ((String?) -> Unit)? = null

    private var px = 0f
    private var pz = 3f
    private var lastNs = 0L

    private var program = 0
    private var aPos = 0
    private var aNormal = 0
    private var uMVP = 0
    private var uModel = 0
    private var uColor = 0
    private var uGlow = 0
    private lateinit var cube: FloatBuffer

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val viewport = IntArray(4)
    private var vpH = 1

    fun setBooks(list: List<Book>) {
        layout = WorldBuilder.build(list)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.53f, 0.81f, 0.92f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)

        val vs = """
            uniform mat4 uMVP;
            uniform mat4 uModel;
            attribute vec3 aPos;
            attribute vec3 aNormal;
            varying vec3 vN;
            varying float vDist;
            void main() {
                vN = normalize(vec3(uModel * vec4(aNormal, 0.0)));
                gl_Position = uMVP * vec4(aPos, 1.0);
                vDist = gl_Position.w;
            }
        """.trimIndent()
        val fs = """
            precision mediump float;
            uniform vec4 uColor;
            uniform float uGlow;
            varying vec3 vN;
            varying float vDist;
            void main() {
                vec3 L = normalize(vec3(0.4, 0.8, 0.5));
                float diff = max(dot(normalize(vN), L), 0.0);
                vec3 c = uColor.rgb * (0.45 + 0.65 * diff) + uGlow * vec3(0.30, 0.22, 0.05);
                float fog = clamp((vDist - 50.0) / 120.0, 0.0, 1.0);
                gl_FragColor = vec4(mix(c, vec3(0.53, 0.81, 0.92), fog), 1.0);
            }
        """.trimIndent()

        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(program, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(program)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aNormal = GLES20.glGetAttribLocation(program, "aNormal")
        uMVP = GLES20.glGetUniformLocation(program, "uMVP")
        uModel = GLES20.glGetUniformLocation(program, "uModel")
        uColor = GLES20.glGetUniformLocation(program, "uColor")
        uGlow = GLES20.glGetUniformLocation(program, "uGlow")

        val data = cubeData()
        cube = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        cube.put(data).position(0)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }

    /** Cubo unidad centrado en el origen: 36 vertices con posicion y normal. */
    private fun cubeData(): FloatArray {
        val normals = arrayOf(
            floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f),
            floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, -1f, 0f),
            floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f)
        )
        val corners = arrayOf(
            intArrayOf(-1, -1), intArrayOf(1, -1), intArrayOf(1, 1),
            intArrayOf(-1, -1), intArrayOf(1, 1), intArrayOf(-1, 1)
        )
        val out = ArrayList<Float>()
        for (n in normals) {
            val u: FloatArray
            val v: FloatArray
            if (n[0] != 0f) {
                u = floatArrayOf(0f, 1f, 0f); v = floatArrayOf(0f, 0f, 1f)
            } else if (n[1] != 0f) {
                u = floatArrayOf(1f, 0f, 0f); v = floatArrayOf(0f, 0f, 1f)
            } else {
                u = floatArrayOf(1f, 0f, 0f); v = floatArrayOf(0f, 1f, 0f)
            }
            for (c in corners) {
                for (k in 0..2) out.add(0.5f * n[k] + 0.5f * c[0] * u[k] + 0.5f * c[1] * v[k])
                for (k in 0..2) out.add(n[k])
            }
        }
        return out.toFloatArray()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        viewport[0] = 0; viewport[1] = 0; viewport[2] = width; viewport[3] = height
        vpH = height
        Matrix.perspectiveM(proj, 0, 65f, width.toFloat() / max(1, height), 0.1f, 220f)
    }

    private fun blocked(x: Float, z: Float): Boolean {
        for (r in layout.shelves) {
            if (x > r[0] && x < r[1] && z > r[2] && z < r[3]) return true
        }
        return false
    }

    private fun update(dt: Float) {
        val tp = teleportId
        if (tp != null) {
            teleportId = null
            val b = layout.books.firstOrNull { it.bookId == tp }
            if (b != null) {
                px = b.cx
                pz = b.cz + 2.2f
                yaw = 0f
                pitch = -5f
            }
        }
        val mx = moveX
        val my = moveY
        if (mx != 0f || my != 0f) {
            val yr = Math.toRadians(yaw.toDouble())
            val fx = sin(yr).toFloat()
            val fz = -cos(yr).toFloat()
            val rx = cos(yr).toFloat()
            val rz = sin(yr).toFloat()
            val speed = 4.5f * dt
            val dx = (fx * my + rx * mx) * speed
            val dz = (fz * my + rz * mx) * speed
            if (!blocked(px + dx, pz)) px += dx
            if (!blocked(px, pz + dz)) pz += dz
            px = px.coerceIn(-190f, 190f)
            pz = pz.coerceIn(-190f, 190f)
        }
    }

    private fun draw(b: Box, glow: Float, scale: Float) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, b.cx, b.cy, b.cz)
        Matrix.scaleM(model, 0, b.sx * scale, b.sy * scale, b.sz * scale)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform4f(uColor, b.r, b.g, b.b, 1f)
        GLES20.glUniform1f(uGlow, glow)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else min(0.1f, (now - lastNs) / 1e9f)
        lastNs = now
        update(dt)

        val yr = Math.toRadians(yaw.toDouble())
        val pr = Math.toRadians(pitch.toDouble())
        val dx = (cos(pr) * sin(yr)).toFloat()
        val dy = sin(pr).toFloat()
        val dz = (-cos(pr) * cos(yr)).toFloat()
        Matrix.setLookAtM(view, 0, px, 1.7f, pz, px + dx, 1.7f + dy, pz + dz, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)
        cube.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, cube)
        GLES20.glEnableVertexAttribArray(aPos)
        cube.position(3)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, 24, cube)
        GLES20.glEnableVertexAttribArray(aNormal)

        val l = layout
        for (b in l.statics) draw(b, 0f, 1f)
        val sel = selectedId
        for (b in l.books) {
            if (b.bookId != null && b.bookId == sel) draw(b, 1f, 1.07f) else draw(b, 0f, 1f)
        }
    }

    /** Se llama en el hilo de GL (glView.queueEvent): lanza un rayo desde el punto tocado. */
    fun pick(x: Float, y: Float) {
        val near = FloatArray(4)
        val far = FloatArray(4)
        val winY = vpH - y
        GLU.gluUnProject(x, winY, 0f, view, 0, proj, 0, viewport, 0, near, 0)
        GLU.gluUnProject(x, winY, 1f, view, 0, proj, 0, viewport, 0, far, 0)
        for (i in 0..2) {
            near[i] /= near[3]
            far[i] /= far[3]
        }
        var dx = far[0] - near[0]
        var dy = far[1] - near[1]
        var dz = far[2] - near[2]
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        dx /= len; dy /= len; dz /= len

        var bestT = 14f
        var best: String? = null
        for (b in layout.books) {
            val t = rayBox(near[0], near[1], near[2], dx, dy, dz, b)
            if (t >= 0f && t < bestT) {
                bestT = t
                best = b.bookId
            }
        }
        onPick?.invoke(best)
    }

    private fun rayBox(ox: Float, oy: Float, oz: Float, dx: Float, dy: Float, dz: Float, b: Box): Float {
        val o = floatArrayOf(ox, oy, oz)
        val d = floatArrayOf(dx, dy, dz)
        val mn = floatArrayOf(b.cx - b.sx / 2f, b.cy - b.sy / 2f, b.cz - b.sz / 2f)
        val mxs = floatArrayOf(b.cx + b.sx / 2f, b.cy + b.sy / 2f, b.cz + b.sz / 2f)
        var tmin = 0f
        var tmax = Float.MAX_VALUE
        for (i in 0..2) {
            if (abs(d[i]) < 1e-6f) {
                if (o[i] < mn[i] || o[i] > mxs[i]) return -1f
            } else {
                var t1 = (mn[i] - o[i]) / d[i]
                var t2 = (mxs[i] - o[i]) / d[i]
                if (t1 > t2) { val t = t1; t1 = t2; t2 = t }
                tmin = max(tmin, t1)
                tmax = min(tmax, t2)
                if (tmin > tmax) return -1f
            }
        }
        return tmin
    }
}
