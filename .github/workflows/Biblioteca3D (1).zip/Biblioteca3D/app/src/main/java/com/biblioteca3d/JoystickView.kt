package com.biblioteca3d

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** Joystick virtual: entrega (x, y) entre -1 y 1; y positivo = avanzar. */
class JoystickView(ctx: Context) : View(ctx) {
    var onChange: ((Float, Float) -> Unit)? = null

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x44FFFFFF; style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCCFFFFFF.toInt(); style = Paint.Style.FILL
    }
    private var kx = 0f
    private var ky = 0f

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 4f
        canvas.drawCircle(cx, cy, r, basePaint)
        canvas.drawCircle(cx, cy, r, ringPaint)
        canvas.drawCircle(cx + kx, cy + ky, r * 0.35f, knobPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val reach = min(width, height) / 2f * 0.6f
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val dx = e.getX(0) - width / 2f
                val dy = e.getY(0) - height / 2f
                val len = hypot(dx, dy)
                val k = if (len > reach) reach / len else 1f
                kx = dx * k
                ky = dy * k
                onChange?.invoke(kx / reach, -ky / reach)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                kx = 0f
                ky = 0f
                onChange?.invoke(0f, 0f)
            }
        }
        invalidate()
        return true
    }
}
