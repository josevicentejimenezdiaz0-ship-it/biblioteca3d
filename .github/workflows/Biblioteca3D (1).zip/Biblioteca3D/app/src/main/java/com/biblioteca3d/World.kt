package com.biblioteca3d

import java.util.Random
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Una caja con color: todo el mundo se dibuja con cajas (muy ligero para ARMv7). */
class Box(
    val cx: Float, val cy: Float, val cz: Float,
    val sx: Float, val sy: Float, val sz: Float,
    val r: Float, val g: Float, val b: Float,
    val bookId: String? = null
)

/**
 * statics: suelo, estanterias, arboles.
 * books: una caja por libro (las que se pueden tocar).
 * shelves: rectangulos [minX, maxX, minZ, maxZ] con los que el jugador choca.
 */
class Layout(val statics: List<Box>, val books: List<Box>, val shelves: List<FloatArray>)

object WorldBuilder {
    const val COLS = 5
    const val SLOTS = 8
    const val LEVELS = 3
    const val PER_SHELF = SLOTS * LEVELS
    const val SHELF_W = 6.2f
    const val SLOT_W = 0.75f
    const val SPACING_X = 7.4f
    const val SPACING_Z = 6f
    const val LEVEL_H = 1.05f

    fun build(books: List<Book>): Layout {
        val statics = ArrayList<Box>()
        val bookBoxes = ArrayList<Box>()
        val rects = ArrayList<FloatArray>()

        val shelfCount = max(1, ceil(books.size / PER_SHELF.toFloat()).toInt())
        val rows = ceil(shelfCount / COLS.toFloat()).toInt()

        // Suelo del mundo y plaza de piedra bajo la biblioteca
        val zMax = 4f
        val zMin = -11f - (rows - 1) * SPACING_Z
        val plazaW = min(COLS, shelfCount) * SPACING_X + 6f
        statics.add(Box(0f, -0.5f, 0f, 400f, 1f, 400f, 0.35f, 0.62f, 0.30f))
        statics.add(Box(0f, 0f, (zMax + zMin) / 2f, plazaW, 0.06f, zMax - zMin, 0.80f, 0.76f, 0.66f))

        val wood = floatArrayOf(0.45f, 0.30f, 0.18f)
        val plank = floatArrayOf(0.58f, 0.40f, 0.24f)

        for (s in 0 until shelfCount) {
            val row = s / COLS
            val col = s % COLS
            val inRow = min(COLS, shelfCount - row * COLS)
            val sx = (col - (inRow - 1) / 2f) * SPACING_X
            val sz = -7f - row * SPACING_Z

            // Estructura: fondo, laterales y 4 baldas
            statics.add(Box(sx, 1.7f, sz - 0.38f, SHELF_W, 3.4f, 0.08f, wood[0], wood[1], wood[2]))
            statics.add(Box(sx - SHELF_W / 2f + 0.05f, 1.7f, sz, 0.1f, 3.4f, 0.8f, wood[0], wood[1], wood[2]))
            statics.add(Box(sx + SHELF_W / 2f - 0.05f, 1.7f, sz, 0.1f, 3.4f, 0.8f, wood[0], wood[1], wood[2]))
            for (k in 0..LEVELS) {
                statics.add(Box(sx, 0.1f + k * LEVEL_H, sz, SHELF_W, 0.1f, 0.8f, plank[0], plank[1], plank[2]))
            }
            rects.add(floatArrayOf(sx - SHELF_W / 2f - 0.35f, sx + SHELF_W / 2f + 0.35f, sz - 0.5f, sz + 0.8f))
        }

        // Libros: el orden de la lista decide en que estanteria, balda y hueco va cada uno
        books.forEachIndexed { i, b ->
            val s = i / PER_SHELF
            val j = i % PER_SHELF
            val level = j / SLOTS
            val slot = j % SLOTS
            val row = s / COLS
            val col = s % COLS
            val inRow = min(COLS, shelfCount - row * COLS)
            val shelfX = (col - (inRow - 1) / 2f) * SPACING_X
            val shelfZ = -7f - row * SPACING_Z

            val h = b.id.hashCode()
            val tone = 0.75f + 0.4f * ((h and 0xFF) / 255f)
            val height = 0.65f + 0.25f * (((h shr 8) and 0xFF) / 255f)
            val mb = b.size / 1048576f
            val thick = (0.16f + 0.12f * ln(1f + mb)).coerceIn(0.16f, 0.62f)

            val (r, g, bl) = when (b.type) {
                "pdf" -> Triple(0.80f, 0.22f, 0.20f)
                "epub" -> Triple(0.25f, 0.65f, 0.35f)
                else -> Triple(0.25f, 0.45f, 0.85f)
            }
            val x = shelfX - SHELF_W / 2f + 0.1f + slot * SLOT_W + SLOT_W / 2f
            val y = 0.15f + level * LEVEL_H + height / 2f
            val z = shelfZ + 0.05f + (if (b.reading) 0.35f else 0f)
            bookBoxes.add(Box(x, y, z, thick, height, 0.55f,
                min(1f, r * tone), min(1f, g * tone), min(1f, bl * tone), b.id))
        }

        // Arboles repartidos por el mundo abierto, lejos de la plaza
        val rnd = Random(7)
        repeat(260) {
            val x = (rnd.nextFloat() - 0.5f) * 360f
            val z = (rnd.nextFloat() - 0.5f) * 360f
            val inPlaza = x > -plazaW / 2f - 8f && x < plazaW / 2f + 8f && z < zMax + 8f && z > zMin - 8f
            if (!inPlaza) {
                val leaf = 0.55f + 0.35f * rnd.nextFloat()
                statics.add(Box(x, 1.0f, z, 0.5f, 2f, 0.5f, 0.40f, 0.26f, 0.14f))
                statics.add(Box(x, 3.1f, z, 2.2f, 2.4f, 2.2f, 0.12f, leaf * 0.6f, 0.15f))
            }
        }
        return Layout(statics, bookBoxes, rects)
    }
}
