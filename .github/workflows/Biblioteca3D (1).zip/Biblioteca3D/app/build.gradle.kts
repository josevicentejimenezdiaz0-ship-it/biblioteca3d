plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.biblioteca3d"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.biblioteca3d"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Solo ARM de 32 bits (armeabi-v7a). La app no usa codigo nativo propio:
        // el 3D es OpenGL ES 2.0 desde Kotlin, asi que funciona igual en esa ABI.
        ndk {
            abiFilters += listOf("armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
